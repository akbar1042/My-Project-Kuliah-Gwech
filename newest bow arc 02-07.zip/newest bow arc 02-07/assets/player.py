import pygame
import math

BLACK = (0, 0, 0)
YELLOW = (255, 230, 0)
RED = (255, 70, 70)

class Player:
    
    def __init__(self, x, y, health, damage, width, height, image):
        self.x = x
        self.y = y
        
        self.width = width
        self.height = height
        
        self.arrow_x = self.x
        self.arrow_y = self.y
        
        self.vx = 0
        self.vy = 0
        
        self.arrow_flying = False
        self.dragging = False
        
        
        self.trail_points = []
        
        self.__health = health
        self.__power = damage
        
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image,
                                            (self.width, self.height))
        
        
    def get_health(self):
        return self.__health
    
    def get_power(self):
        return self.__power
    
    def set_health(self, value):
        if value < 0:
            value = 0
            
        self.__health = value
        
    def set_power(self, value):
        if value < 0:
            value = 0
        
        self.__power = value
        
    def diserang(self, value):
        self.__health -= value
        
        if self.__health < 0:
            self.__health = 0
            
    def draw_player(self, screen, camera_x):
        screen_x = self.x - camera_x

        player_rect = self.image.get_rect(
            center=(screen_x, self.y)
        )
        
        screen.blit(self.image, player_rect)

        pygame.draw.arc(
            screen,
            BLACK,
            (
                screen_x - 20,
                self.y - 45,
                40,
                90
            ),
            math.radians(-90),
            math.radians(90),
            4
        )

    def draw_arrow(self, screen, camera_x):
        
        screen_x = self.arrow_x - camera_x

        angle = math.atan2(-self.vy, self.vx)
        
        length = 40

        end_x = screen_x + math.cos(angle) * length
        end_y = self.arrow_y - math.sin(angle) * length

        pygame.draw.line(
            screen,
            BLACK,
            (screen_x, self.arrow_y),
            (end_x, end_y),
            5
        )

        pygame.draw.circle(
            screen,
            YELLOW,
            (int(end_x), int(end_y)),
            5
        )

    # =====================================
    # DRAW PREDICTION
    # =====================================
    def draw_prediction(self, screen, start_x, start_y, power_x, power_y, camera_x):

        temp_x = start_x
        temp_y = start_y
        
        temp_vx = power_x
        temp_vy = power_y

        for i in range(60):

            temp_x += temp_vx
            temp_y += temp_vy

            temp_vy += 0.6

            screen_x = temp_x - camera_x

            pygame.draw.circle(
                screen,
                (255, 0 ,0),
                (int(screen_x), int(temp_y)),
                3
            )

    # =====================================
    # RESET PLAYER ARROW
    # =====================================
    def reset_arrow(self):

        self.arrow_x = self.x
        self.arrow_y = self.y

        self.vx = 0
        self.vy = 0

        self.arrow_flying = False
        self.trail_points.clear()
