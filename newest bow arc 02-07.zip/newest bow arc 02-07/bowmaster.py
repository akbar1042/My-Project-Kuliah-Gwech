import pygame
import math
import random
import pause as pause_menu
import save_system
import gameover

from player1 import Player
from enemy1  import Enemy
from settings import draw_health_bar, draw_power_bar, draw_round
from shop import GOLD_LIGHT

# =====================================
# KONSTANTA
# =====================================
WHITE  = (255, 255, 255)
BLACK  = (0,   0,   0)
GREEN  = (50,  220, 50)
BLUE   = (50,  100, 255)
GRAY   = (180, 180, 180)
YELLOW = (255, 230, 0)
RED    = (220, 50,  50)
DARK   = (20,  20,  20)

WORLD_WIDTH  = 3000
GROUND_Y     = 580

player_x      = 325
player_y      = 510
player_width  = 180
player_height = 320
enemy_width   = player_width
enemy_height  = player_height

# =====================================
# STATE GLOBAL
# =====================================
camera_x    = 0
shake_timer = 0
gravity     = 0.6
data        = save_system.load_data()
coin        = data["coin"]

enemy  = None
player = None
font   = None
font_big = None
langit = None
tanah  = None
paused = False
round_number = 1

enemy_death_anim = False

round_transition = False
round_alpha      = 0
round_timer      = 0

# ── GIF efek yang sedang diputar di layar ──────────────────────────────────
# Format: {"frames": [...], "index": int, "tick": int, "delay": int,
#          "elapsed": int, "duration": int, "x": int, "y": int}
_active_gif = None

CHARACTER_DATA = {
    "Ciro": {
        "image"      : "assets/Characters/ciro11.png",
        "projectile" : "projektil1.png",
        "skill"      : "triple_shot",
        "skill_gif"  : None,
        "skill_image": None,
    },
    "Lulia": {
        "image"      : "assets/Characters/lulia11.png",
        "projectile" : "projektil2.png",
        "skill"      : "winter_knockout",
        "skill_gif"  : "assets/es.gif",
        "skill_image": None,
    },
    "John": {
        "image"      : "assets/Characters/jon11.png",
        "projectile" : "projektil3.png",
        "skill"      : "firestorm_shot",
        "skill_gif"  : "assets/api.gif",
        "skill_image": None,
    },
}

ENEMY_TYPES = [
    {
        "image"      : "assets/Characters/ciro11.png",
        "projektil" : "projektil1.png",
    },
    {
        "image"      : "assets/Characters/lulia11.png",
        "projektil" : "projektil2.png",
    },
    {
        "image"      : "assets/Characters/jon11.png",
        "projektil" : "projektil3.png",
    }
]
# ──────────────────────────────────────────────────────────────────────────────
# HELPER: load GIF frames (pakai PIL)
# ──────────────────────────────────────────────────────────────────────────────
def _load_gif_frames(path, scale=None):
    frames = []
    try:
        from PIL import Image as PILImage
        gif = PILImage.open(path)
        i = 0
        while True:
            gif.seek(i)
            rgba = gif.convert("RGBA")
            w, h = rgba.size
            surf = pygame.image.fromstring(rgba.tobytes(), (w, h), "RGBA").convert_alpha()
            if scale:
                surf = pygame.transform.scale(surf, scale)
            frames.append(surf)
            i += 1
    except EOFError:
        pass
    except Exception as e:
        print(f"[GIF] gagal load '{path}': {e}")
    return frames


def _play_gif(path, x, y, scale=(150, 150), delay=4):
    """Mulai putar GIF efek di posisi world (x, y)."""
    global _active_gif
    frames = _load_gif_frames(path, scale)
    if not frames:
        return
    _active_gif = {
        "frames"  : frames,
        "index"   : 0,
        "tick"    : 0,
        "delay"   : delay,
        "elapsed" : 0,
        "duration": len(frames) * delay,
        "x"       : x,
        "y"       : y,
    }


def _update_gif():
    global _active_gif
    if _active_gif is None:
        return
    g = _active_gif
    g["elapsed"] += 1
    g["tick"]    += 1
    if g["tick"] >= g["delay"]:
        g["tick"]  = 0
        g["index"] = (g["index"] + 1) % len(g["frames"])
    if g["elapsed"] >= g["duration"]:
        _active_gif = None


def _draw_gif(screen, camera_x):
    if _active_gif is None:
        return
    g    = _active_gif
    surf = g["frames"][g["index"]]
    rect = surf.get_rect(center=(int(g["x"] - camera_x), int(g["y"])))
    screen.blit(surf, rect)


# ──────────────────────────────────────────────────────────────────────────────
# UTIL: karakter equipped
# ──────────────────────────────────────────────────────────────────────────────
def _get_equipped_character():
    d = save_system.load_data()
    for name in ["Ciro", "Lulia", "John"]:
        if d.get(name, {}).get("equipped", False):
            return name, d[name]
    return "Ciro", d["Ciro"]


# ──────────────────────────────────────────────────────────────────────────────
# DRAW WORLD
# ──────────────────────────────────────────────────────────────────────────────
def draw_world(screen, WIDTH, HEIGHT):
    global camera_x

    for x in range(0, WORLD_WIDTH + 1200, 1200):
        screen.blit(langit, (x - camera_x, 0))
        screen.blit(tanah,  (x - camera_x, 0))

    player.draw_player(screen, camera_x)
    enemy.draw(screen, camera_x)

    # ── GIF efek ──────────────────────────────────────────────────────────────
    _draw_gif(screen, camera_x)

    if player.dragging:
        mx, my = pygame.mouse.get_pos()
        dx = player.x - 15 - mx
        dy = player.y - 25 - my
        distance = math.sqrt(dx**2 + dy**2)
        power = min(distance, 250)

        if distance > 230:
            scale = 230 / distance
            dx   *= scale
            dy   *= scale

        player.draw_prediction(screen, player.x, player.y,
                               dx * 0.22, dy * 0.22, camera_x)
        draw_power_bar(screen, 30, 100, power, 250)

        power_val = int(math.sqrt(dx * dx + dy * dy))
        screen.blit(font.render(f"Power : {power_val}", True, WHITE), (30, 140))

    # trail + arrow player
    if player.arrow_flying:
        for point in player.trail_points:
            pygame.draw.circle(screen, (120, 120, 120),
                               (int(point[0] - camera_x), int(point[1])), 4)
        player.draw_arrow(screen, camera_x)

    # panah ekstra (triple shot)
    if player.extra_arrows:
        player.draw_extra_arrows(screen, camera_x)

    if enemy.arrow_flying:
        enemy.draw_arrow(screen, camera_x)

    # UI health
    draw_health_bar(screen, 30,  30, player.get_health(), 100)
    draw_health_bar(screen, 910, 30, enemy.get_health(),  100)

    # jarak meter
    if not player.arrow_flying and not enemy.turn_active and not player.extra_arrows:
        jarak     = (enemy.x - player.x) / 10
        jarak_img = pygame.image.load("assets/jarak.png")
        jarak_img = pygame.transform.scale(jarak_img, (100, 40))
        screen.blit(jarak_img, (1070, HEIGHT // 2 - 15))
        screen.blit(
            font.render(f"{jarak}m", True, GOLD_LIGHT),
            (1085, (HEIGHT // 2) - 8)
        )

    # koin
    coin_image = pygame.image.load("assets/coin.png")
    coin_image = pygame.transform.scale(coin_image, (30, 30))
    screen.blit(coin_image, (275, 28))
    screen.blit(font.render(f"{coin}", True, WHITE), (312, 33))

    # tombol skill
    if not enemy.turn_active and not game_over_flag:
        player.draw_skill_button(screen, font, x=30, y=170)

    draw_round(screen, round_number + 1, WIDTH // 2, HEIGHT // 2, round_alpha)


# ──────────────────────────────────────────────────────────────────────────────
# UPDATE LOGIC
# ──────────────────────────────────────────────────────────────────────────────
def update_logic(HEIGHT):
    global camera_x, coin, shake_timer

    # kamera follow
    target_camera = player.arrow_x - 600
    if enemy.turn_active and not enemy.arrow_flying:
        target_camera = enemy.x - 600
    if enemy.arrow_flying:
        target_camera = enemy.arrow_x - 600

    camera_x += (target_camera - camera_x) * 0.08

    if shake_timer > 0:
        shake_timer -= 1
        camera_x    += math.sin(pygame.time.get_ticks() * 0.8) * 8

    camera_x = max(0, min(camera_x, WORLD_WIDTH - 1200))

    # update GIF
    _update_gif()

    # ── panah utama player ────────────────────────────────────────────────────
    if player.arrow_flying:
        player.update_proj_gif()   # animasi GIF projektil (firestorm)
        player.arrow_x += player.vx
        player.arrow_y += player.vy
        player.trail_points.append((player.arrow_x, player.arrow_y))
        if len(player.trail_points) > 20:
            player.trail_points.pop(0)
        player.vy += gravity
        player.vx *= 0.995

        hit = _check_arrow_hit_enemy(player.arrow_x, player.arrow_y, is_main=True)

        if hit:
            # Panah utama kena — start turn hanya kalau tidak ada extra arrows
            if not player.extra_arrows and enemy.get_health() > 0 and not enemy.turn_active:
                enemy.move_random()
                enemy.start_turn(player.x, player.y)
                player.tick_turn_cooldown()

        if not hit:
            if player.arrow_x > WORLD_WIDTH or player.arrow_y > GROUND_Y:
                # Panah utama miss — start turn kalau tidak ada extra arrows
                player.reset_arrow()
                player.clear_skill_damage_multiplier()
                if not player.extra_arrows:
                    enemy.start_turn(player.x, player.y)
                    player.tick_turn_cooldown()

    # ── panah ekstra (triple shot) ────────────────────────────────────────────
    still_alive = []
    for a in player.extra_arrows:
        a["x"] += a["vx"]
        a["y"] += a["vy"]
        a["vy"] += gravity
        a["vx"] *= 0.995
        a["trail"].append((a["x"], a["y"]))
        if len(a["trail"]) > 20:
            a["trail"].pop(0)

        hit_extra = _check_arrow_hit_enemy(a["x"], a["y"], is_main=False)
        if not hit_extra:
            if a["y"] < GROUND_Y and a["x"] < WORLD_WIDTH:
                still_alive.append(a)
    prev_extra_count   = len(player.extra_arrows)
    player.extra_arrows = still_alive

    # Semua extra arrows baru saja habis & panah utama sudah selesai
    # → baru sekarang start enemy turn
    if prev_extra_count > 0 and len(player.extra_arrows) == 0 and not player.arrow_flying:
        if getattr(player, '_last_skill_used', None) == "triple_shot":
            player.clear_skill_damage_multiplier()
        if enemy.get_health() > 0 and not enemy.turn_active:
            enemy.move_random()
            enemy.start_turn(player.x, player.y)
            player.tick_turn_cooldown()

    enemy.update(HEIGHT)

    # ── panah enemy mengenai player ───────────────────────────────────────────
    if (player.x - player.width  // 2 < enemy.arrow_x < player.x + player.width  // 2
            and player.y - player.height // 2 < enemy.arrow_y < player.y + player.height // 2):
        enemy.has_hit_player = True
        enemy.arrow_flying   = False
        enemy.turn_active    = False
        enemy.arrow_x        = -1000
        enemy.arrow_y        = -1000
        player.diserang(enemy.get_damage())


def _check_arrow_hit_enemy(ax, ay, is_main):
    """
    Cek apakah panah di (ax, ay) mengenai enemy.
    is_main: True = panah utama player, False = panah ekstra.
    Return True jika hit.
    """
    global coin, shake_timer
    if (enemy.x - enemy_width  // 2 < ax < enemy.x + enemy_width  // 2
            and enemy.y - enemy_height // 2 < ay < enemy.y + enemy_height // 2):

        if is_main:
            skill_used = getattr(player, '_last_skill_used', None)
            dmg = player.get_skill_damage()
            if skill_used != "triple_shot":
                player.clear_skill_damage_multiplier()

            # ── winter_knockout: musuh skip 1 turn (freeze) ───────────────────
            if skill_used == "winter_knockout":
                enemy.frozen_turns = getattr(enemy, 'frozen_turns', 0) + 1

            # ── firestorm_shot: musuh terbakar 3 turn (-5% max HP per turn) ───
            if skill_used == "firestorm_shot":
                enemy.burn_turns = 3
                enemy.burn_damage = max(1, int(enemy.get_health() * 0.05))

        else:
            if getattr(player, '_last_skill_used', None) == "triple_shot":
                dmg = player.get_skill_damage()
            else:
                dmg = player.get_damage()

        enemy.diserang(dmg)
        coin += random.randint(5, 15)
        data["coin"] = coin
        save_system.save_data(data)
        shake_timer = 12

        if is_main:
            player.reset_arrow()

        return True
    return False


# ──────────────────────────────────────────────────────────────────────────────
# HANDLE EVENT
# ──────────────────────────────────────────────────────────────────────────────
def handle_event(event):
    global _active_gif

    if enemy.turn_active:
        return

    # ── Tombol Q = aktifkan skill ─────────────────────────────────────────────
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_q:
            if not player.arrow_flying and not player.extra_arrows:
                player.activate_skill()

    if event.type == pygame.MOUSEBUTTONDOWN:
        if not player.arrow_flying and not player.extra_arrows:
            player.dragging = True

    if event.type == pygame.MOUSEBUTTONUP:
        if player.dragging:
            player.dragging = False
            mx, my = pygame.mouse.get_pos()
            dx = player.x - 15 - mx
            dy = player.y - 25 - my
            distance = math.sqrt(dx**2 + dy**2)
            if distance > 190:
                scale = 190 / distance
                dx   *= scale
                dy   *= scale

            vx = dx * 0.22
            vy = dy * 0.22

            player.launch(vx, vy)


# ──────────────────────────────────────────────────────────────────────────────
# game_over_flag (dipakai draw_world untuk hide tombol skill saat game over)
# ──────────────────────────────────────────────────────────────────────────────
game_over_flag = False


# ──────────────────────────────────────────────────────────────────────────────
# INISIALISASI
# ──────────────────────────────────────────────────────────────────────────────
def _init_game():
    global enemy, player, font, font_big, langit, tanah
    global round_number, enemy_death_anim, round_transition, round_alpha, round_timer
    global _active_gif, game_over_flag, data, coin

    # Reload save data setiap restart agar karakter equipped selalu up-to-date
    data = save_system.load_data()
    coin = data["coin"]

    round_number     = 1
    round_transition = False
    round_timer      = 0
    round_alpha      = 0
    enemy_death_anim = False
    _active_gif      = None
    game_over_flag   = False

    char_name, char_data = _get_equipped_character()
    cd = CHARACTER_DATA[char_name]
    
    enemy_data = random.choice(ENEMY_TYPES)

    enemy = Enemy(
        enemy_data["image"],
        enemy_data["projektil"],
        100 + ((round_number - 1) * 20),
        10 + ((round_number - 1) * 20)
        
    )

    player = Player(
        player_x, player_y,
        char_data["hp"],
        char_data["atk"],
        player_width, player_height,
        cd["image"],
        cd["projectile"],
        skill_name=cd["skill"],
    )

    # Kalau karakter punya skill image (Lulia) → preload
    if cd.get("skill_image"):
        player.set_skill_image(cd["skill_image"])

    # Kalau skill pakai GIF sebagai projektil terbang (Lulia & John) → preload
    if cd.get("skill_gif") and cd["skill"] in ("firestorm_shot", "winter_knockout"):
        frames = _load_gif_frames(cd["skill_gif"], scale=(60, 60))
        if frames:
            player.set_projectile_gif(frames, delay=3)

    font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 24)
    font_big = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 56)

    langit = pygame.image.load("assets/arena.png")
    tanah  = pygame.image.load("assets/tanah.png")


# ──────────────────────────────────────────────────────────────────────────────
# RUN GAME
# ──────────────────────────────────────────────────────────────────────────────
def run_game(screen):
    global paused, round_number, round_transition, round_alpha
    global enemy_death_anim, enemy, round_timer, game_over_flag

    WIDTH  = 1200
    HEIGHT = 700

    _init_game()

    clock      = pygame.time.Clock()
    paused     = False
    game_over  = False

    pause_btns   = {}
    endgame_btns = {}

    while True:
        clock.tick(60)

        # ── cek win/lose ──────────────────────────────────────────────────────
        if not game_over:
            if player.get_health() <= 0:
                game_over      = True
                game_over_flag = True
                paused         = False
            elif enemy.get_health() <= 0 and not enemy_death_anim and not enemy.dead:
                enemy_death_anim = True
                enemy.dead       = True

        if enemy_death_anim:
            selesai = enemy.update_death()
            if selesai:
                enemy_death_anim = False
                round_transition = True
                round_timer      = 0
                
                player.reset_extra_arrows()
                player.reset_arrow()

        # ── transisi round ────────────────────────────────────────────────────
        if round_transition:
            round_timer += 1
            if round_timer < 10:
                round_alpha = min(255, round_alpha + 18)
            elif round_timer < 45:
                round_alpha = 255
            elif round_timer < 60:
                round_alpha = max(0, round_alpha - 18)
            else:
                round_transition = False
                round_alpha      = 0
                round_number    += 1
                
                enemy_data = random.choice(ENEMY_TYPES)

                enemy = Enemy(
                    enemy_data["image"],
                    enemy_data["projektil"],
                    100 + ((round_number - 1) * 20),
                    10 + ((round_number - 1) * 20)
                    
                )
                
                enemy.x    = random.randint(player_x + 2100, 2500)
                enemy.dead = False

        # ── event loop ────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return None

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not game_over:
                    paused = not paused
                    if paused:
                        player.dragging = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if paused and not game_over:
                    if pause_btns.get("resume") and pause_btns["resume"].collidepoint(mx, my):
                        paused = False
                    elif pause_btns.get("restart") and pause_btns["restart"].collidepoint(mx, my):
                        _init_game(); paused = False; game_over = False
                    elif pause_btns.get("mainmenu") and pause_btns["mainmenu"].collidepoint(mx, my):
                        return "mainmenu"
                    elif pause_btns.get("quit") and pause_btns["quit"].collidepoint(mx, my):
                        pygame.quit(); return None

                elif game_over:
                    if endgame_btns.get("restart") and endgame_btns["restart"].collidepoint(mx, my):
                        _init_game()
                        player.dragging = False
                        player.reset_arrow()
                        pygame.event.clear()
                        paused = False; game_over = False; game_over_flag = False
                        continue
                    elif endgame_btns.get("mainmenu") and endgame_btns["mainmenu"].collidepoint(mx, my):
                        return "mainmenu"

            if not paused and not game_over:
                handle_event(event)

        # ── logika fisika ─────────────────────────────────────────────────────
        if not paused and not game_over and not enemy_death_anim and not round_transition:
            update_logic(HEIGHT)

        # ── render ────────────────────────────────────────────────────────────
        draw_world(screen, WIDTH, HEIGHT)

        if round_transition:
            draw_round(screen, round_number + 1, WIDTH // 2, HEIGHT // 2, round_alpha)

        if paused and not game_over:
            result = pause_menu.run(screen)
            if result == "resume":
                paused = False
            elif result == "restart":
                _init_game(); paused = False; game_over = False
            elif result == "menu":
                return "mainmenu"
            elif result == "quit":
                pygame.quit(); return None

        if game_over:
            endgame_btns = gameover.draw_endgame(screen, WIDTH, HEIGHT,)

        pygame.display.update()