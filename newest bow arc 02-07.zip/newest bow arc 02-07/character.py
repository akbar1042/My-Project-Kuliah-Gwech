import pygame
import math
import os

BLACK  = (0, 0, 0)
YELLOW = (255, 230, 0)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: load semua frame .gif (pakai PIL) sebagai list Surface
# ─────────────────────────────────────────────────────────────────────────────
def _load_gif_frames(path, scale=None):
    frames = []
    try:
        from PIL import Image as PILImage
        gif = PILImage.open(path)
        i = 0
        while True:
            gif.seek(i)
            rgba = gif.convert("RGBA")
            w, h = rgba.size
            surf = pygame.image.fromstring(rgba.tobytes(), (w, h), "RGBA").convert_alpha()
            if scale:
                surf = pygame.transform.scale(surf, scale)
            frames.append(surf)
            i += 1
    except EOFError:
        pass
    except Exception as e:
        print(f"[GIF] gagal load '{path}': {e}")
    return frames if frames else None


class Character:

    def __init__(self, x, y, health, damage, width, height, image, projektil):
        self.x = x
        self.y = y

        self.arrow_x = x - 15
        self.arrow_y = y - 25

        self.image_path   = image
        self.projektil_path = projektil

        self.vx = 0
        self.vy = 0

        self.__health = health
        self.__damage = damage

        self.width  = width
        self.height = height

        self.trail_points = []
        self.arrow_flying = False

        self._assets_dir = os.path.dirname(image)

        self.image = pygame.image.load(image).convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))
        # simpan original (belum di-flip) untuk animasi kematian enemy
        self.image_original = self.image.copy()

        # Load arrow sprite
        arrow_path = os.path.join(self._assets_dir, self.projektil_path)
        if os.path.exists(arrow_path):
            self.arrow_sprite = pygame.image.load(arrow_path).convert_alpha()
        else:
            self.arrow_sprite = None

        self._image_cache = {}

        # ── skill state (dipakai Player) ─────────────────────────────────────
        # Cooldown berbasis TURN: skill_cooldown_turns berkurang 1 setiap kali
        # player selesai menembak (giliran berakhir), bukan per frame.
        self.skill_name            = ""       # diset oleh Player.__init__
        self.skill_cooldown_turns  = 0        # sisa cooldown dalam turn
        self.skill_max_cooldown    = 3        # default 3 turn cooldown
        self.skill_active          = False    # True selama efek skill berlangsung

        # GIF effect state
        self._gif_frames     = []    # list Surface dari .gif
        self._gif_index      = 0
        self._gif_tick       = 0
        self._gif_delay      = 4     # frame per gif-frame
        self._gif_active     = False
        self._gif_duration   = 0     # total tick sebelum gif selesai
        self._gif_elapsed    = 0
        self._gif_x          = 0
        self._gif_y          = 0

        # override image saat skill aktif (Lulia)
        self._skill_image        = None   # Surface pengganti saat skill
        self._skill_image_active = False

    # ── frame loader ─────────────────────────────────────────────────────────
    def _load_frame(self, img_index, variant):
        key = (img_index, variant)
        if key in self._image_cache:
            return self._image_cache[key]

        base_filename = os.path.basename(self.image_path)
        prefix = ''.join(filter(str.isalpha, base_filename.split('.')[0]))

        path = os.path.join(self._assets_dir, f"{prefix}{img_index}{variant}.png")

        if os.path.exists(path):
            try:
                img = pygame.image.load(path)
                img = pygame.transform.scale(img, (self.width, self.height))
                self._image_cache[key] = img
                return img
            except Exception:
                pass
        return self.image

    # ── getters / setters ────────────────────────────────────────────────────
    def get_health(self):  return self.__health
    def get_damage(self):  return self.__damage

    def set_health(self, value):
        self.__health = max(0, value)

    def set_damage(self, value):
        self.__damage = max(0, value)

    def diserang(self, value):
        if value < 0:
            value = 0
        self.__health = max(0, self.__health - value)

    # ── GIF effect ───────────────────────────────────────────────────────────
    def play_gif_effect(self, gif_path, x, y, scale=None, delay=4):
        """
        Putar animasi GIF di posisi (x, y) sebagai efek satu kali.
        gif_path : path ke file .gif
        x, y     : posisi CENTER animasi di world-space
        scale    : (w, h) atau None
        delay    : game-tick per frame gif
        """
        frames = _load_gif_frames(gif_path, scale)
        if not frames:
            return
        self._gif_frames   = frames
        self._gif_index    = 0
        self._gif_tick     = 0
        self._gif_delay    = delay
        self._gif_active   = True
        self._gif_duration = len(frames) * delay
        self._gif_elapsed  = 0
        self._gif_x        = x
        self._gif_y        = y

    def update_gif(self):
        """Panggil tiap frame saat gif aktif."""
        if not self._gif_active:
            return
        self._gif_elapsed += 1
        self._gif_tick    += 1
        if self._gif_tick >= self._gif_delay:
            self._gif_tick  = 0
            self._gif_index = (self._gif_index + 1) % len(self._gif_frames)
        if self._gif_elapsed >= self._gif_duration:
            self._gif_active = False

    def draw_gif_effect(self, screen, camera_x):
        if not self._gif_active or not self._gif_frames:
            return
        surf = self._gif_frames[self._gif_index]
        rect = surf.get_rect(center=(int(self._gif_x - camera_x), int(self._gif_y)))
        screen.blit(surf, rect)

    # ── skill image override (Lulia) ─────────────────────────────────────────
    def set_skill_image(self, image_path):
        """Load image alternatif yang dipakai saat skill aktif."""
        if os.path.exists(image_path):
            img = pygame.image.load(image_path).convert_alpha()
            img = pygame.transform.scale(img, (self.width, self.height))
            self._skill_image = img
        else:
            print(f"[Character] skill image tidak ditemukan: {image_path}")

    def _get_current_image(self):
        """Kembalikan image yang tepat (normal / skill-override)."""
        if self._skill_image_active and self._skill_image is not None:
            return self._skill_image
        return self.image

    # ── cooldown berbasis turn ────────────────────────────────────────────────
    def tick_turn_cooldown(self):
        """
        Panggil ini SEKALI setiap kali giliran player selesai
        (setelah panah mendarat / meleset).
        """
        if self.skill_cooldown_turns > 0:
            self.skill_cooldown_turns -= 1

    def skill_ready(self):
        return self.skill_cooldown_turns == 0

    # ── draw character ────────────────────────────────────────────────────────
    def draw_character(self, screen, camera_x):
        screen_x    = self.x - camera_x
        img_index   = getattr(self, 'img_index', None)
        facing_left = getattr(self, '_facing_left', False)

        # Tentukan frame animasi berdasarkan state
        if img_index is not None and getattr(self, 'dragging', False):
            frame = self._load_frame(img_index, 1)
        elif img_index is not None and getattr(self, 'arrow_flying', False):
            frame = self._load_frame(img_index, 2)
        else:
            # Pakai skill-image jika sedang aktif, sinon image normal
            frame = self._get_current_image()

        if facing_left:
            frame = pygame.transform.flip(frame, True, False)

        rect = frame.get_rect(center=(screen_x, self.y))
        screen.blit(frame, rect)

    # ── draw arrow ────────────────────────────────────────────────────────────
    def draw_arrow(self, screen, camera_x):
        screen_x = self.arrow_x - camera_x

        if self.vx == 0 and self.vy == 0:
            angle = 0.0
        else:
            angle = math.atan2(self.vy, self.vx)

        if self.arrow_sprite is not None:
            deg     = math.degrees(angle)
            rotated = pygame.transform.rotate(self.arrow_sprite, -deg)
            rect    = rotated.get_rect(center=(int(screen_x), int(self.arrow_y)))
            screen.blit(rotated, rect)
        else:
            end_x = screen_x     + math.cos(angle) * 40
            end_y = self.arrow_y + math.sin(angle) * 40
            pygame.draw.line(
                screen,
                BLACK,
                (screen_x, self.arrow_y),
                (end_x, end_y),
                5
                )
            pygame.draw.circle(screen, YELLOW, (int(end_x), int(end_y)), 5)

    # ── reset arrow ───────────────────────────────────────────────────────────
    def reset_arrow(self):
        if getattr(self, '_facing_left', False):
            self.arrow_x = self.x + 15
        else:
            self.arrow_x = self.x - 15

        self.arrow_y      = self.y - 25
        self.vx           = 0
        self.vy           = 0
        self.arrow_flying = False
        self.trail_points.clear()