import pygame
import math
import random

from character import Character

BLACK = (0, 0, 0)
RED   = (255, 70, 70)

class Enemy(Character):

    def __init__(self, image, projektil, hp, damage,):
        super().__init__(2400, 510, hp, damage, 180, 320, image, projektil)
        self.img_index = 1

        self._facing_left = True   # ← flag untuk reset_arrow & draw_arrow

        self.preview_vx = 0
        self.preview_vy = 0
        self.gravity = 0.35

        self.turn_active = False
        self.aim_time = 60  # waktu aim sebelum musuh melepaskan panah
        self.current_aim = 0
        self.has_hit_player = False

        self.dead = False
        self.death_angle = 0
        self.death_y_offset = 0

        # ── efek status ───────────────────────────────────────────────────────
        self.frozen_turns = 0   # winter_knockout: skip turn sebanyak ini
        self.burn_turns   = 0   # firestorm_shot : terbakar N turn
        self.burn_damage  = 0   # damage per tick burn
        
    # ── draw ──────────────────────────────────────────────────────────────────
    def draw(self, screen, camera_x):
        if self.dead:
            # Gunakan image_original; fallback ke self.image jika belum ada
            src = getattr(self, 'image_original', self.image)

            # Pastikan surface punya alpha channel agar rotate tidak crash
            if src.get_flags() & pygame.SRCALPHA == 0:
                src = src.convert_alpha()

            rotated = pygame.transform.rotate(src, -self.death_angle)
            rotated = pygame.transform.flip(rotated, True, False)

            rect = rotated.get_rect(
                midbottom=(
                    self.x - camera_x,
                    510 + self.height // 2
                )
            )
            screen.blit(rotated, rect)
            return
        
        super().draw_character(screen, camera_x)

        if self.turn_active and not self.arrow_flying:
            temp_x  = self.x
            temp_y  = self.y
            temp_vx = self.preview_vx
            temp_vy = self.preview_vy

            for i in range(60):
                temp_x += temp_vx
                temp_y += temp_vy
                temp_vy += self.gravity
                pygame.draw.circle(
                    screen, RED,
                    (int(temp_x - camera_x), int(temp_y)), 3
                )

            radian  = math.atan2(self.preview_vy, self.preview_vx)
            degrees = math.degrees(radian)

            if degrees < -60:
                self.img_index = 7
            elif degrees < -30:
                self.img_index = 6
            elif degrees <   0:
                self.img_index = 5
            elif degrees <  30:
                self.img_index = 4
            elif degrees <  60:
                self.img_index = 3
            elif degrees <  90:
                self.img_index = 2
            else:
                self.img_index = 1

    # ── start turn ────────────────────────────────────────────────────────────
    def start_turn(self, player_x, player_y):
        # ── burn: kurangi HP sebelum giliran dimulai ──────────────────────────
        if self.burn_turns > 0:
            self.diserang(self.burn_damage)
            self.burn_turns -= 1
            if self.burn_turns == 0:
                self.burn_damage = 0

        # ── frozen: skip giliran ini ──────────────────────────────────────────
        if self.frozen_turns > 0:
            self.frozen_turns -= 1
            # Tidak set turn_active → giliran dilewati
            return

        self.turn_active    = True
        self.arrow_x        = self.x + 15   # sisi kiri karakter (enemy hadap kiri)
        self.arrow_y        = self.y - 25
        self.arrow_flying   = False
        self.has_hit_player = False
        self.current_aim    = self.aim_time

        dx = player_x - self.x
        dy = player_y - self.y
        if dx == 0:
            dx = 0.1

        distance = abs(dx)
        speed    = math.sqrt(distance) * 0.9
        speed    = max(18, min(45, speed))

        inside = (
            speed**4
            - self.gravity * (
                self.gravity * (dx**2)
                + 2 * dy * (speed**2)
            )
        )
        inside     = max(0, inside)
        sqrt_value = math.sqrt(inside)
        angle      = math.atan(
            (speed**2 - sqrt_value) / (self.gravity * abs(dx))
        )

        direction       = 1 if dx > 0 else -1
        self.preview_vx = math.cos(angle) * speed * direction
        self.preview_vy = -math.sin(angle) * speed

        accuracy = random.uniform(93, 100)
        error    = (100 - accuracy) / 3
        self.preview_vx += random.uniform(-error, error)
        self.preview_vy += random.uniform(-error, error)

        # pastikan arah vx tidak berubah karena error random
        if direction == -1 and self.preview_vx > 0:
            self.preview_vx *= -1
        elif direction == 1 and self.preview_vx < 0:
            self.preview_vx *= -1

    # ── move random ───────────────────────────────────────────────────────────
    def move_random(self):
        move   = random.randint(-80, 120)
        self.x = max(1900, min(2800, self.x + move))

    # ── update ────────────────────────────────────────────────────────────────
    def update(self, HEIGHT):
        if not self.turn_active:
            return

        if not self.arrow_flying:
            self.current_aim -= 1
            if self.current_aim <= 0:
                self.vx = self.preview_vx
                self.vy = self.preview_vy
                self.arrow_flying = True
        else:
            self.arrow_x += self.vx
            self.arrow_y += self.vy
            self.vy += self.gravity
            self.vx *= 0.995

            if (self.arrow_y > HEIGHT
                    or self.arrow_x < 0
                    or self.arrow_x > 5000):
                
                self.turn_active  = False
                self.arrow_flying = False

    def update_death(self):
        if self.death_angle < 90:
            self.death_angle += 3
            return False
        return True