import pygame

pygame.init()

WIDTH  = 1200
HEIGHT = 700

# =====================================
# LOAD IMAGE
# =====================================
chisato_img = pygame.image.load("assets/loding.png")

image_width  = 600
image_height = 300

chisato_img = pygame.transform.scale(chisato_img, (image_width, image_height))

image_x = (WIDTH  - image_width)  // 2
image_y = (HEIGHT - image_height) // 2

# =====================================
# WARNA
# =====================================
BLACK      = (0,   0,   0)
WHITE      = (255, 255, 255)
YELLOW     = (255, 230,  0)
DARK_GRAY  = (40,  40,  40)


# =====================================
# HELPER — gambar loading bar
# =====================================
def _draw_loading_bar(screen, font, progress: float, label: str):
    """
    progress : 0.0 – 1.0
    label    : teks di atas bar  (contoh: "Loading...", "Saving...")
    """
    bar_w, bar_h = 400, 18
    bar_x = (WIDTH  - bar_w) // 2
    bar_y = HEIGHT - 110

    # latar bar
    pygame.draw.rect(screen, DARK_GRAY, (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4),
                     border_radius=10)
    # isi bar
    fill_w = int(bar_w * max(0.0, min(1.0, progress)))
    if fill_w > 0:
        pygame.draw.rect(screen, YELLOW, (bar_x, bar_y, fill_w, bar_h),
                         border_radius=8)
    # border bar
    pygame.draw.rect(screen, WHITE, (bar_x - 2, bar_y - 2, bar_w + 4, bar_h + 4),
                     2, border_radius=10)

    # teks label
    txt = font.render(label, True, WHITE)
    screen.blit(txt, txt.get_rect(center=(WIDTH // 2, bar_y - 28)))

    # persentase
    pct = font.render(f"{int(progress * 100)}%", True, YELLOW)
    screen.blit(pct, pct.get_rect(center=(WIDTH // 2, bar_y + bar_h + 22)))


# =====================================
# FADE IN  (intro — sama seperti aslinya)
# =====================================
def fade_in_image(screen):
    for alpha in range(0, 256, 5):
        image = chisato_img.copy()
        image.set_alpha(alpha)
        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))
        pygame.display.update()
        pygame.time.delay(20)


# =====================================
# FADE OUT  (intro — sama seperti aslinya)
# =====================================
def fade_out_image(screen):
    for alpha in range(255, -1, -5):
        image = chisato_img.copy()
        image.set_alpha(alpha)
        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))
        pygame.display.update()
        pygame.time.delay(20)


# =====================================
# LOADING SCREEN — masuk game
# =====================================
def loading_start(screen, label="Loading..."):
    """
    Tampil saat mau masuk gameplay.
    Fade-in gambar + loading bar dari 0% → 100%, lalu fade-out.
    """
    font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 22)

    # --- fase 1: fade in gambar sambil bar naik 0→60% ---
    steps = 51                          # 0,5,10,...,255  → 51 langkah
    for i, alpha in enumerate(range(0, 256, 5)):
        progress = (i / steps) * 0.6    # 0.0 → 0.60

        image = chisato_img.copy()
        image.set_alpha(alpha)
        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))
        _draw_loading_bar(screen, font, progress, label)
        pygame.display.update()
        pygame.time.delay(18)

    # --- fase 2: bar naik 60→100% (gambar penuh) ---
    for step in range(31):              # 30 langkah
        progress = 0.6 + (step / 30) * 0.4

        screen.fill(BLACK)
        screen.blit(chisato_img, (image_x, image_y))
        _draw_loading_bar(screen, font, progress, label)
        pygame.display.update()
        pygame.time.delay(22)

    # tahan sebentar di 100%
    pygame.time.delay(300)

    # --- fase 3: fade out ---
    for alpha in range(255, -1, -5):
        image = chisato_img.copy()
        image.set_alpha(alpha)
        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))
        _draw_loading_bar(screen, font, 1.0, label)
        pygame.display.update()
        pygame.time.delay(14)


# =====================================
# LOADING SCREEN — keluar / ke main menu
# =====================================
def loading_exit(screen, label="Return to Menu"):
    
    font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 28)

    # fade in
    for alpha in range(0, 256, 8):
        image = chisato_img.copy()
        image.set_alpha(alpha)

        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))

        # tulisan
        text = font.render(label, True, WHITE)
        screen.blit(text, text.get_rect(center=(WIDTH // 2, HEIGHT - 90)))

        pygame.display.update()
        pygame.time.delay(12)

    pygame.time.delay(400)

    # fade out
    for alpha in range(255, -1, -5):
        image = chisato_img.copy()
        image.set_alpha(alpha)

        screen.fill(BLACK)
        screen.blit(image, (image_x, image_y))

        # tulisan
        text = font.render(label, True, WHITE)
        screen.blit(text, text.get_rect(center=(WIDTH // 2, HEIGHT - 90)))

        pygame.display.update()
        pygame.time.delay(14)