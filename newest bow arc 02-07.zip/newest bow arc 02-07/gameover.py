import pygame


def draw_endgame(screen, WIDTH, HEIGHT,):

    # =====================================
    # LOAD ASSET
    # =====================================

    gameover_img = pygame.image.load(
        "assets/gameover.png"
    ).convert_alpha()

    restart_normal = pygame.image.load(
        "assets/restart.png"
    ).convert_alpha()

    restart_hover = pygame.image.load(
        "assets/restart2.png"
    ).convert_alpha()

    menu_normal = pygame.image.load(
        "assets/main.png"
    ).convert_alpha()

    menu_hover = pygame.image.load(
        "assets/main2.png"
    ).convert_alpha()

    mx, my = pygame.mouse.get_pos()

    # =====================================
    # SETTING PANEL
    # =====================================
        # GAME OVER
    panel_w = 850
    panel_h = 520

    bg_img = gameover_img

    bg_img = pygame.transform.scale(
        bg_img,
        (panel_w, panel_h)
    )

    bg_x = (WIDTH - panel_w) // 2
    bg_y = (HEIGHT - panel_h) // 2

    screen.blit(bg_img, (bg_x, bg_y))

    # =====================================
    # UKURAN TOMBOL
    # =====================================

    restart_w = 250
    restart_h = 86

    menu_w = 250
    menu_h = 91

    restart_normal = pygame.transform.scale(
        restart_normal,
        (restart_w, restart_h)
    )

    restart_hover = pygame.transform.scale(
        restart_hover,
        (restart_w, restart_h)
    )

    menu_normal = pygame.transform.scale(
        menu_normal,
        (menu_w, menu_h)
    )

    menu_hover = pygame.transform.scale(
        menu_hover,
        (menu_w, menu_h)
    )

    # =====================================
    # POSISI & UKURAN TOMBOL LOSE
    # =====================================
    restart_w = 260
    restart_h = 85

    menu_w = 260
    menu_h = 85

        # BERDERET KE BAWAH
    restart_x = bg_x + (panel_w - restart_w) // 2
    restart_y = bg_y + 230

    menu_x = bg_x + (panel_w - menu_w) // 2
    menu_y = bg_y + 330
    # =====================================
    # RECT
    # =====================================

    restart_rect = pygame.Rect(
        restart_x,
        restart_y,
        restart_w,
        restart_h
    )

    menu_rect = pygame.Rect(
        menu_x,
        menu_y,
        menu_w,
        menu_h
    )

    # =====================================
    # DRAW RESTART
    # =====================================

    if restart_rect.collidepoint(mx, my):
        screen.blit(
            restart_hover,
            (restart_x, restart_y)
        )
    else:
        screen.blit(
            restart_normal,
            (restart_x, restart_y)
        )

    # =====================================
    # DRAW MENU
    # =====================================

    if menu_rect.collidepoint(mx, my):
        screen.blit(
            menu_hover,
            (menu_x, menu_y)
        )
    else:
        screen.blit(
            menu_normal,
            (menu_x, menu_y)
        )

    return {
        "restart": restart_rect,
        "mainmenu": menu_rect
    }