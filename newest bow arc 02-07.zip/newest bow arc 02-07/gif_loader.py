"""
gif_loader.py  –  Utility untuk load & render file .gif di Pygame.

Cara pakai:
    from gif_loader import GifSprite

    # Di init / load:
    anim = GifSprite("assets/es.gif", scale=(200, 200))

    # Di update loop (tiap frame):
    anim.update()

    # Di draw loop:
    anim.draw(screen, x, y)          # x, y = center posisi
    # atau ambil surface frame saat ini:
    surf = anim.current_surface()
"""

import pygame


class GifSprite:
    """
    Memuat semua frame dari file .gif dan memutarnya secara looping.

    Parameters
    ----------
    path        : str   – path ke file .gif
    scale       : tuple – (width, height) untuk scale setiap frame, atau None
    frame_delay : int   – jumlah game-tick per frame (default 6 ≈ 10 fps di 60 fps)
    """

    def __init__(self, path: str, scale=None, frame_delay: int = 6):
        self.frames: list[pygame.Surface] = []
        self.frame_delay  = frame_delay
        self._tick        = 0
        self._frame_index = 0
        self.visible      = True

        # ── muat frame menggunakan PIL (tersedia di semua Python env modern) ──
        try:
            from PIL import Image as PILImage

            gif = PILImage.open(path)
            frame_idx = 0
            while True:
                gif.seek(frame_idx)
                rgba = gif.convert("RGBA")
                w, h = rgba.size
                raw  = rgba.tobytes()
                surf = pygame.image.fromstring(raw, (w, h), "RGBA").convert_alpha()

                if scale:
                    surf = pygame.transform.scale(surf, scale)

                self.frames.append(surf)
                frame_idx += 1

        except EOFError:
            pass  # semua frame sudah diload
        except Exception as e:
            print(f"[GifSprite] Gagal load '{path}': {e}")
            # fallback: surface kosong 1x1
            fallback = pygame.Surface((1, 1), pygame.SRCALPHA)
            self.frames = [fallback]

        if not self.frames:
            fallback = pygame.Surface((1, 1), pygame.SRCALPHA)
            self.frames = [fallback]

    # ── update (panggil tiap game tick) ──────────────────────────────────────
    def update(self):
        self._tick += 1
        if self._tick >= self.frame_delay:
            self._tick = 0
            self._frame_index = (self._frame_index + 1) % len(self.frames)

    # ── ambil surface frame saat ini ─────────────────────────────────────────
    def current_surface(self) -> pygame.Surface:
        return self.frames[self._frame_index]

    # ── draw ke screen (center di x, y) ──────────────────────────────────────
    def draw(self, screen: pygame.Surface, x: int, y: int):
        if not self.visible:
            return
        surf = self.current_surface()
        rect = surf.get_rect(center=(x, y))
        screen.blit(surf, rect)

    # ── reset ke frame awal ───────────────────────────────────────────────────
    def reset(self):
        self._tick        = 0
        self._frame_index = 0

    def __len__(self):
        return len(self.frames)
