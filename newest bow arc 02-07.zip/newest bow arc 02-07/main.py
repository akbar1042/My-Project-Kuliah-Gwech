import pygame
import sys

from fade import fade_in_image, fade_out_image, loading_start, loading_exit

import main_menu
import bowmaster

pygame.init()

WIDTH  = 1200
HEIGHT = 700

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("R.I.P Aim")
pygame.display.set_icon(pygame.image.load("assets/logo.png"))

# =====================================
# INTRO  (sekali saat pertama buka)
# =====================================
pygame.time.delay(500)
fade_in_image(screen)
pygame.time.delay(1000)
fade_out_image(screen)

# =====================================
# LOOP UTAMA  (main menu ↔ game)
# =====================================
while True:
    # --- Main Menu ---
    start_game = main_menu.run(screen)

    if not start_game:
        # Quit dari main menu → loading keluar lalu tutup
        loading_exit(screen, label="Goodbye...")
        break

    # --- Loading masuk game ---
    loading_start(screen, label="Loading...")

    # --- Game ---
    result = bowmaster.run_game(screen)

    if result == "mainmenu":
        # Tombol Main Menu di pause → loading transition ke menu
        loading_exit(screen, label="Returning to Menu...")
        # lanjut loop → main menu ditampilkan lagi

    elif result is None:
        # Quit total (X window / Keluar Game di pause)
        loading_exit(screen, label="Goodbye...")
        break

pygame.quit()
sys.exit()