import pygame
import tutor
import shop

pygame.init()
pygame.mixer.init()

WIDTH  = 1200
HEIGHT = 700

# =========================
# MUSIC (MENU BGM)
# =========================
menu_bgm = pygame.mixer.Sound("assets/sound/medieval.mp3")
menu_bgm.set_volume(0.5)

bgm_playing = False
bgm_stopped_time = None


# =========================
# SFX
# =========================
click_sfx = pygame.mixer.Sound("assets/sound/pop.mp3")
back_sfx  = pygame.mixer.Sound("assets/sound/hah.mp3")

click_sfx.set_volume(0.6)



# =========================
# LOAD ASSET
# =========================
play1 = pygame.transform.scale(pygame.image.load("assets/play1.png"), (250, 85))
play2 = pygame.transform.scale(pygame.image.load("assets/play2.png"), (250, 85))
shop1 = pygame.transform.scale(pygame.image.load("assets/shop.png"),  (250, 85))
shop2 = pygame.transform.scale(pygame.image.load("assets/shop2.png"), (250, 85))
quit1 = pygame.transform.scale(pygame.image.load("assets/quit.png"),  (250, 85))
quit2 = pygame.transform.scale(pygame.image.load("assets/quit2.png"), (250, 85))
info1 = pygame.transform.scale(pygame.image.load("assets/info.png"),  (120, 120))
info2 = pygame.transform.scale(pygame.image.load("assets/info2.png"), (120, 120))


# =========================
# POSISI TOMBOL
# =========================
play_x, play_y = (WIDTH - 250) // 2, 260
shop_x, shop_y = (WIDTH - 250) // 2, 380
quit_x, quit_y = (WIDTH - 250) // 2, 500
info_x = WIDTH - 120 - 20
info_y = HEIGHT - 120 - 20

play_rect = pygame.Rect(play_x, play_y, 250, 85)
shop_rect = pygame.Rect(shop_x, shop_y, 250, 85)
quit_rect = pygame.Rect(quit_x, quit_y, 250, 85)
info_rect = pygame.Rect(info_x, info_y, 120, 120)

clock = pygame.time.Clock()


# =========================
# GIF LOADER
# =========================
def load_gif(path, w, h):
    frames = []
    try:
        from PIL import Image
        gif = Image.open(path)

        try:
            while True:
                frame = gif.copy().convert("RGBA")
                surf = pygame.image.fromstring(
                    frame.tobytes(), frame.size, "RGBA"
                ).convert_alpha()
                frames.append(pygame.transform.scale(surf, (w, h)))
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass

    except ImportError:
        surf = pygame.image.load(path).convert_alpha()
        frames.append(pygame.transform.scale(surf, (w, h)))

    if not frames:
        frames = [pygame.Surface((w, h), pygame.SRCALPHA)]

    return frames


# =========================
# RUN MENU
# =========================
def run(screen):
    global bgm_playing, bgm_stopped_time

    bg_frames = load_gif("assets/mainan.gif", WIDTH, HEIGHT)
    bg_idx = 0

    aim_frames = load_gif("assets/rip.gif", 180, 180)
    rip_frames = load_gif("assets/aim.gif", 180, 180)

    aim_idx = 0
    rip_idx = 0
    timer = 0
    delay = 6

    total_w = 180 * 2 + 40
    aim_x = (WIDTH - total_w) // 2
    rip_x = aim_x + 220
    gif_y = 60

    running = True
    start_game = False


    # =========================
    # MUSIC START LOGIC (3 DETIK)
    # =========================
    if bgm_stopped_time:
        if pygame.time.get_ticks() - bgm_stopped_time >= 3000:
            menu_bgm.play(-1)
            bgm_playing = True
            bgm_stopped_time = None

    if not bgm_playing:
        pygame.time.delay(3000)
        menu_bgm.play(-1)
        bgm_playing = True


    # =========================
    # MAIN LOOP
    # =========================
    while running:
        clock.tick(60)
        mouse = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu_bgm.stop()
                bgm_playing = False
                pygame.quit()
                return False

            if event.type == pygame.MOUSEBUTTONDOWN:

                # =========================
                # PLAY
                # =========================
                if play_rect.collidepoint(mouse):
                    click_sfx.play()
                    menu_bgm.stop()
                    bgm_playing = False
                    start_game = True
                    running = False

                # =========================
                # SHOP (musik tetap jalan)
                # =========================
                if shop_rect.collidepoint(mouse):
                    click_sfx.play()
                    shop.run(screen)

                # =========================
                # QUIT
                # =========================
                if quit_rect.collidepoint(mouse):
                    click_sfx.play()
                    menu_bgm.stop()
                    bgm_playing = False
                    pygame.quit()
                    return False

                # =========================
                # INFO (musik tetap jalan)
                # =========================
                if info_rect.collidepoint(mouse):
                    click_sfx.play()
                    tutor.run(screen)


        # =========================
        # ANIMATION UPDATE
        # =========================
        timer += 1
        if timer >= delay:
            timer = 0
            bg_idx = (bg_idx + 1) % len(bg_frames)
            aim_idx = (aim_idx + 1) % len(aim_frames)
            rip_idx = (rip_idx + 1) % len(rip_frames)


        # =========================
        # DRAW
        # =========================
        screen.blit(bg_frames[bg_idx], (0, 0))
        screen.blit(aim_frames[aim_idx], (aim_x, gif_y))
        screen.blit(rip_frames[rip_idx], (rip_x, gif_y))

        screen.blit(play2 if play_rect.collidepoint(mouse) else play1, (play_x, play_y))
        screen.blit(shop2 if shop_rect.collidepoint(mouse) else shop1, (shop_x, shop_y))
        screen.blit(quit2 if quit_rect.collidepoint(mouse) else quit1, (quit_x, quit_y))
        screen.blit(info2 if info_rect.collidepoint(mouse) else info1, (info_x, info_y))

        pygame.display.update()

    return start_game