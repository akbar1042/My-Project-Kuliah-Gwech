import pygame

pygame.init()
pygame.mixer.init()

WIDTH = 1200
HEIGHT = 700

# =========================
# SOUND
# =========================
swosh_sound = pygame.mixer.Sound(
    "assets/sound/swosh.mp3"
)

pop_sound = pygame.mixer.Sound(
    "assets/sound/pop.mp3"
)

bip_sound = pygame.mixer.Sound(
    "assets/sound/bip.mp3"
)

cancel_sound = pygame.mixer.Sound(
    "assets/sound/cancel.mp3"
)

# =========================
# BACKGROUND PAUSE
# =========================
pause_bg = pygame.image.load("assets/pause.png")

bg_width = 900
bg_height = 520

pause_bg = pygame.transform.scale(
    pause_bg,
    (bg_width, bg_height)
)

bg_x = (WIDTH - bg_width) // 2
bg_y = (HEIGHT - bg_height) // 2

# =========================
# TOMBOL RESUME
# =========================
resume1 = pygame.image.load("assets/resume.png")
resume2 = pygame.image.load("assets/resume2.png")

button_width = 260
button_height = 85

resume1 = pygame.transform.scale(
    resume1,
    (button_width, button_height)
)

resume2 = pygame.transform.scale(
    resume2,
    (button_width, button_height)
)

# =========================
# TOMBOL RESTART
# =========================
restart1 = pygame.image.load("assets/restart.png")
restart2 = pygame.image.load("assets/restart2.png")

restart1 = pygame.transform.scale(
    restart1,
    (button_width, button_height)
)

restart2 = pygame.transform.scale(
    restart2,
    (button_width, button_height)
)

# =========================
# TOMBOL MAIN MENU
# =========================
menu1 = pygame.image.load("assets/main.png")
menu2 = pygame.image.load("assets/main2.png")

menu1 = pygame.transform.scale(
    menu1,
    (button_width, button_height)
)

menu2 = pygame.transform.scale(
    menu2,
    (button_width, button_height)
)

# =========================
# POSISI TOMBOL
# =========================
resume_x = bg_x + (bg_width - button_width) // 2
resume_y = bg_y + 154

restart_x = bg_x + (bg_width - button_width) // 2
restart_y = bg_y + 244

menu_x = bg_x + (bg_width - button_width) // 2
menu_y = bg_y + 334

# =========================
# RECT
# =========================
resume_rect = pygame.Rect(
    resume_x,
    resume_y,
    button_width,
    button_height
)

restart_rect = pygame.Rect(
    restart_x,
    restart_y,
    button_width,
    button_height
)

menu_rect = pygame.Rect(
    menu_x,
    menu_y,
    button_width,
    button_height
)

clock = pygame.time.Clock()


def run(screen):

    import main_menu

    while True:

        clock.tick(60)

        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                return "quit"

            # =========================
            # SPACE = RESUME
            # =========================
            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_SPACE:

                    swosh_sound.play()
                    pygame.time.wait(120)

                    return "resume"

            # =========================
            # MOUSE CLICK
            # =========================
            if event.type == pygame.MOUSEBUTTONDOWN:

                # RESUME
                if resume_rect.collidepoint(mouse_pos):

                    pop_sound.play()
                    pygame.time.wait(120)

                    return "resume"

                # RESTART
                if restart_rect.collidepoint(mouse_pos):

                    bip_sound.play()
                    pygame.time.wait(120)

                    return "restart"

                # MAIN MENU
                if menu_rect.collidepoint(mouse_pos):

                    cancel_sound.play()
                    pygame.time.wait(120)

                    return "menu"

        # =========================
        # BACKGROUND
        # =========================
        screen.blit(
            pause_bg,
            (bg_x, bg_y)
        )

        # =========================
        # RESUME
        # =========================
        if resume_rect.collidepoint(mouse_pos):
            screen.blit(
                resume2,
                (resume_x, resume_y)
            )
        else:
            screen.blit(
                resume1,
                (resume_x, resume_y)
            )

        # =========================
        # RESTART
        # =========================
        if restart_rect.collidepoint(mouse_pos):
            screen.blit(
                restart2,
                (restart_x, restart_y)
            )
        else:
            screen.blit(
                restart1,
                (restart_x, restart_y)
            )

        # =========================
        # MAIN MENU
        # =========================
        if menu_rect.collidepoint(mouse_pos):
            screen.blit(
                menu2,
                (menu_x, menu_y)
            )
        else:
            screen.blit(
                menu1,
                (menu_x, menu_y)
            )

        pygame.display.update()