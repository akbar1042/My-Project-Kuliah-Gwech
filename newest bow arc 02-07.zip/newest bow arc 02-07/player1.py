import pygame
import math

from character import Character

BLACK = (0, 0, 0)


class Player(Character):
    """
    Skill yang tersedia:
      - Ciro  → "triple_shot"   : 3 panah sekaligus, offset X berbeda (hujan panah)
      - Lulia → "winter_knockout": 1 panah damage tinggi + freeze, ganti asset
      - John  → "firestorm_shot": 1 panah AoE damage sangat tinggi
    Cooldown berbasis TURN (tick_turn_cooldown() dipanggil dari bowmaster).
    """

    # Offset X untuk triple-shot (relatif terhadap vx/vy arah tembakan)
    TRIPLE_OFFSETS = [
        (-60,  0),    # panah kiri
        (  0,  0),    # panah tengah (normal)
        ( 60,  0),    # panah kanan
    ]

    SKILL_DISPLAY_NAMES = {
        "triple_shot": "Triple Shot",
        "winter_knockout": "Winter Knockout",
        "firestorm_shot": "Firestorm Shot",
    }

    def __init__(self, x, y, health, damage, width, height, image, projektil, skill_name=""):
        super().__init__(x, y, health, damage, width, height, image, projektil)
        self.dragging  = False
        self.img_index = 1

        # ── skill setup ───────────────────────────────────────────────────────
        self.skill_name = skill_name

        # Cooldown default per skill (dalam turn)
        _cooldowns = {
            "triple_shot"      : 3,
            "winter_knockout"  : 4,
            "firestorm_shot"   : 5,
        }
        self.skill_max_cooldown   = _cooldowns.get(skill_name, 3)
        self.skill_cooldown_turns = 0   # mulai siap pakai

        # ── triple-shot: simpan state 2 panah ekstra ──────────────────────────
        # Setiap entry: {"x", "y", "vx", "vy", "trail"}
        self.extra_arrows: list[dict] = []

        # ── flag skill sedang aktif (untuk bowmaster) ──────────────────────────
        self.skill_active = False

        # ── firestorm: GIF terbang sebagai projektil ───────────────────────────
        # Diisi dari bowmaster sebelum launch via set_projectile_gif()
        self._proj_gif_frames  = []
        self._proj_gif_index   = 0
        self._proj_gif_tick    = 0
        self._proj_gif_delay   = 4      # tick per frame gif
        self._proj_gif_active  = False  # True saat arrow firestorm sedang terbang
        self._original_arrow_sprite = None  # simpan sprite asli agar bisa dikembalikan

    # ─────────────────────────────────────────────────────────────────────────
    # ACTIVATE SKILL
    # Dipanggil dari bowmaster saat tombol skill ditekan (sebelum tembak).
    # ─────────────────────────────────────────────────────────────────────────
    def activate_skill(self):
        """
        Set flag bahwa tembakan berikutnya akan menggunakan skill.
        Cooldown BELUM dikurangi di sini; dikurangi setelah tembakan selesai.
        """
        if self.skill_cooldown_turns > 0:
            return False  # masih cooldown
        self.skill_active = True
        return True

    # ─────────────────────────────────────────────────────────────────────────
    # LAUNCH  (dipanggil dari bowmaster setelah mouse release)
    # ─────────────────────────────────────────────────────────────────────────
    def launch(self, vx, vy):
        """
        Tembakkan panah dengan kecepatan (vx, vy).
        Jika skill aktif → jalankan efek skill; jika tidak → tembakan biasa.
        """
        if self.skill_active:
            self._launch_skill(vx, vy)
        else:
            self.vx = vx
            self.vy = vy
            self.arrow_flying = True

    def _launch_skill(self, vx, vy):
        """Logika tembakan skill berdasarkan skill_name."""
        name = self.skill_name

        if name == "triple_shot":
            self._skill_damage_multiplier = 3.0
            length = math.sqrt(vx * vx + vy * vy)
            if length == 0:
                length = 1
            perp_x = -vy / length
            perp_y =  vx / length

            # Variasi vy: panah kiri datang lebih awal, kanan lebih lambat
            # Sehingga 3 panah tiba berurutan (efek hujan panah)
            vy_offsets = [-0.5, 0, 0.5]   # kiri cepat, tengah normal, kanan lambat

            self.extra_arrows.clear()
            for i, (ox, _oy) in enumerate(self.TRIPLE_OFFSETS):
                ex  = self.arrow_x + perp_x * ox
                ey  = self.arrow_y + perp_y * ox
                ivy = vy + vy_offsets[i]
                if i == 1:
                    # panah tengah = panah utama
                    self.arrow_x = ex
                    self.arrow_y = ey
                    self.vx = vx
                    self.vy = ivy
                    self.arrow_flying = True
                else:
                    self.extra_arrows.append({
                        "x": ex, "y": ey,
                        "vx": vx, "vy": ivy,
                        "trail": []
                    })

        elif name == "winter_knockout":
            # ── Lulia: 1 panah, damage ×2.5, GIF es terbang sebagai projektil ─
            self._skill_image_active = True   # ganti sprite karakter ke lulia_skill
            self.vx = vx
            self.vy = vy
            self._skill_damage_multiplier = 2.5
            self.arrow_flying = True
            # Aktifkan animasi GIF sebagai projektil (sama seperti firestorm)
            if self._proj_gif_frames:
                self._proj_gif_active = True
                self._proj_gif_index  = 0
                self._proj_gif_tick   = 0
                self._original_arrow_sprite = self.arrow_sprite
                self.arrow_sprite           = None

        elif name == "firestorm_shot":
            # ── John: 1 panah, damage ×4, GIF terbang sebagai projektil ──────
            self.vx = vx
            self.vy = vy
            self._skill_damage_multiplier = 4.0
            self.arrow_flying = True
            # Aktifkan animasi GIF sebagai projektil (jika sudah di-set)
            if self._proj_gif_frames:
                self._proj_gif_active = True
                self._proj_gif_index  = 0
                self._proj_gif_tick   = 0
                # Swap arrow_sprite → None supaya draw_arrow base tidak render
                self._original_arrow_sprite = self.arrow_sprite
                self.arrow_sprite           = None

        else:
            # fallback biasa
            self.vx = vx
            self.vy = vy
            self.arrow_flying = True

        # Set cooldown setelah skill dipakai
        self._last_skill_used     = name   # untuk bowmaster cek efek (freeze/burn)
        self.skill_cooldown_turns = self.skill_max_cooldown
        self.skill_active         = False

    # ─────────────────────────────────────────────────────────────────────────
    # GET DAMAGE (dengan multiplier saat skill)
    # ─────────────────────────────────────────────────────────────────────────
    def get_skill_damage(self):
        base = self.get_damage()
        mult = getattr(self, '_skill_damage_multiplier', 1.0)
        return int(base * mult)

    def clear_skill_damage_multiplier(self):
        self._skill_damage_multiplier = 1.0
        self._skill_image_active      = False
        self._last_skill_used         = None
        # Kembalikan arrow sprite asli setelah skill selesai
        if self._original_arrow_sprite is not None:
            self.arrow_sprite           = self._original_arrow_sprite
            self._original_arrow_sprite = None
        self._proj_gif_active = False

    # ── set GIF frames untuk projektil firestorm ──────────────────────────────
    def set_projectile_gif(self, frames: list, delay: int = 4):
        """
        Isi _proj_gif_frames dengan list Surface (sudah discale).
        Dipanggil dari bowmaster saat init John.
        """
        self._proj_gif_frames = frames
        self._proj_gif_delay  = delay

    def update_proj_gif(self):
        """Maju satu tick animasi GIF projektil. Panggil tiap frame saat terbang."""
        if not self._proj_gif_active or not self._proj_gif_frames:
            return
        self._proj_gif_tick += 1
        if self._proj_gif_tick >= self._proj_gif_delay:
            self._proj_gif_tick  = 0
            self._proj_gif_index = (self._proj_gif_index + 1) % len(self._proj_gif_frames)

    # ── draw_arrow override: render GIF beranimasi sebagai projektil ──────────
    def draw_arrow(self, screen, camera_x):
        if self._proj_gif_active and self._proj_gif_frames:
            # Render frame GIF saat ini di posisi panah, rotasi sesuai arah gerak
            import math as _math
            surf = self._proj_gif_frames[self._proj_gif_index]
            if self.vx == 0 and self.vy == 0:
                angle = 0.0
            else:
                angle = _math.atan2(self.vy, self.vx)
            deg     = _math.degrees(angle)
            rotated = pygame.transform.rotate(surf, -deg)
            rect    = rotated.get_rect(
                center=(int(self.arrow_x - camera_x), int(self.arrow_y))
            )
            screen.blit(rotated, rect)
        else:
            super().draw_arrow(screen, camera_x)

    # ─────────────────────────────────────────────────────────────────────────
    # UPDATE EXTRA ARROWS (triple shot)
    # ─────────────────────────────────────────────────────────────────────────
    def update_extra_arrows(self, gravity, world_width, ground_y):
        """
        Update fisika panah-panah ekstra (triple shot).
        Kembalikan True jika semua panah sudah landing / keluar layar.
        """
        alive = []
        for a in self.extra_arrows:
            a["x"] += a["vx"]
            a["y"] += a["vy"]
            a["vy"] += gravity
            a["vx"] *= 0.995
            a["trail"].append((a["x"], a["y"]))
            if len(a["trail"]) > 20:
                a["trail"].pop(0)
            if a["y"] < ground_y and a["x"] < world_width:
                alive.append(a)
        self.extra_arrows = alive
        return len(self.extra_arrows) == 0

    def reset_extra_arrows(self):
        self.extra_arrows.clear()

    # ─────────────────────────────────────────────────────────────────────────
    # DRAW
    # ─────────────────────────────────────────────────────────────────────────
    def draw_player(self, screen, camera_x):
        super().draw_character(screen, camera_x)

    def draw_extra_arrows(self, screen, camera_x):
        """Gambar panah-panah ekstra (triple shot) beserta trail-nya."""
        for a in self.extra_arrows:
            # trail
            for pt in a["trail"]:
                pygame.draw.circle(screen, (120, 120, 120),
                                   (int(pt[0] - camera_x), int(pt[1])), 3)
            # arrow sprite
            if self.arrow_sprite is not None:
                if a["vx"] == 0 and a["vy"] == 0:
                    angle = 0.0
                else:
                    angle = math.atan2(a["vy"], a["vx"])
                deg     = math.degrees(angle)
                rotated = pygame.transform.rotate(self.arrow_sprite, -deg)
                rect    = rotated.get_rect(
                    center=(int(a["x"] - camera_x), int(a["y"]))
                )
                screen.blit(rotated, rect)

    def draw_prediction(self, screen, start_x, start_y, power_x, power_y, camera_x):
        temp_x  = start_x - 15
        temp_y  = start_y - 25
        temp_vx = power_x
        temp_vy = power_y

        for i in range(60):
            temp_x += temp_vx
            temp_y += temp_vy
            temp_vy += 0.6
            screen_x = temp_x - camera_x
            pygame.draw.circle(
                screen, (255, 0, 0),
                (int(screen_x), int(temp_y)), 3
            )

        radian  = math.atan2(power_y, power_x)
        degrees = math.degrees(radian)

        if degrees < -60:
            self.img_index = 7
        elif degrees < -30:
            self.img_index = 6
        elif degrees < 0:
            self.img_index = 5
        elif degrees < 30:
            self.img_index = 4
        elif degrees < 60:
            self.img_index = 3
        elif degrees < 90:
            self.img_index = 2
        else:
            self.img_index = 1

    # ─────────────────────────────────────────────────────────────────────────
    # SKILL UI helper
    # ─────────────────────────────────────────────────────────────────────────
    def draw_skill_button(self, screen, font, x=30, y=170):
        """
        Gambar tombol skill di HUD.
        Tampilkan nama skill, status ready/cooldown.
        """
        ready  = self.skill_cooldown_turns == 0
        color  = (80, 200, 80) if ready else (160, 80, 80)
        skill_label = self.SKILL_DISPLAY_NAMES.get(
            self.skill_name,
            self.skill_name.replace("_", " ").title()
        )
        label = f"[Q] {skill_label}" if ready else \
                f"[Q] {skill_label} ({self.skill_cooldown_turns}T)"

        pygame.draw.rect(screen, color, (x, y, 260, 36), border_radius=6)
        pygame.draw.rect(screen, (255,255,255), (x, y, 260, 36), 2, border_radius=6)
        txt = font.render(label, True, (255, 255, 255))
        screen.blit(txt, (x + 8, y + 6))