import json
import os

SAVE_FILE = "save_data.json"

def load_data():
    if not os.path.exists(SAVE_FILE):
        data = {
            "coin": 99999999,
            "Ciro": {
                "hp": 100,
                "atk": 5,
                "hp_up": 20,
                "atk_up": 5,
                "hp_price": 10,
                "atk_price": 10,
                "skill": "Triple Shot",
                "owned": True,
                "equipped": True
            },
            "Lulia": {
                "hp": 500,
                "atk": 25,
                "hp_up": 40,
                "atk_up": 10,
                "hp_price": 25,
                "atk_price": 25,
                "skill": "Winter Knockout",
                "owned": False,
                "equipped": False
            },
            "John": {
                "hp": 2500,
                "atk": 12,
                "hp_up": 100,
                "atk_up": 20,
                "hp_price": 125,
                "atk_price": 125,
                "skill": "Firestorm Shot",
                "owned": False,
                "equipped": False
            }
        }

        save_data(data)
        return data

    with open(SAVE_FILE, "r") as file:
        data = json.load(file)
        
    return data


def save_data(data):
    with open(SAVE_FILE, "w") as file:
        json.dump(data, file, indent=4)