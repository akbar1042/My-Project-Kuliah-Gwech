import pygame

BLACK = (0, 0, 0)
RED = (255, 70, 70)
GREEN = (50, 220, 50)

# =====================================
# HEALTH BAR
# =====================================
def draw_health_bar(screen, x, y, health, max_health, width=250, height=25):
    # Hitung persentase health (0-100)
    percentage = (health / max_health) * 100
    
    # Tentukan index gambar (1-11) berdasarkan persentase
    # 11 gambar untuk 11 tingkat health
    image_index = int((percentage / 100) * 11)
    image_index = min(max(image_index, 0), 10)  # Clamp antara 0-10
    
    # Jika image_index 0, gunakan power1/nyawa (full)
    # Jika persentase 0-10%, gunakan nyawa11, dst
    if percentage >= 91:  # 91-100%
        image_num = 12
    elif percentage >= 82:  # 82-90%
        image_num = 2
    elif percentage >= 73:  # 73-81%
        image_num = 3
    elif percentage >= 64:  # 64-72%
        image_num = 4
    elif percentage >= 55:  # 55-63%
        image_num = 5
    elif percentage >= 45:  # 45-54%
        image_num = 6
    elif percentage >= 36:  # 36-44%
        image_num = 7
    elif percentage >= 27:  # 27-35%
        image_num = 8
    elif percentage >= 18:  # 18-26%
        image_num = 9
    elif percentage >= 9:   # 9-17%
        image_num = 10
    else:  # 0-8%
        image_num = 11
    
    # Load gambar berdasarkan index
    if image_num == 12:
        bar_image_path = "assets/nyawa.png"
    else:
        bar_image_path = f"assets/nyawa{image_num}.png"
    
    try:
        bar = pygame.image.load(bar_image_path).convert_alpha()
        bar = pygame.transform.scale(bar, (width, height))
        screen.blit(bar, (x, y))
    except pygame.error as e:
        print(f"Error loading image {bar_image_path}: {e}")


# =====================================
# POWER BAR
# =====================================
def draw_power_bar(screen, x, y, power, max_power, width=250, height=25):
    """
    Menggambar power bar dengan 7 gambar berbeda berdasarkan persentase power.
    
    Args:
        screen: Pygame screen object
        x: Posisi X
        y: Posisi Y
        power: Power saat ini
        max_power: Power maksimal
        width: Lebar bar (default 250)
        height: Tinggi bar (default 25)
    """
    # Gambar border
    pygame.draw.rect(
        screen,
        BLACK,
        (x, y, width, height),
        2
    )
    
    # Hitung persentase power (0-100)
    percentage = (power / max_power) * 100
    
    # Tentukan index gambar (1-7) berdasarkan persentase
    if percentage >= 86:  # 86-100%
        image_num = 7
    elif percentage >= 71:  # 71-85%
        image_num = 6
    elif percentage >= 57:  # 57-70%
        image_num = 5
    elif percentage >= 43:  # 43-56%
        image_num = 4
    elif percentage >= 29:  # 29-42%
        image_num = 3
    elif percentage >= 14:  # 14-28%
        image_num = 2
    else:  # 0-13%
        image_num = 1
    
    # Load gambar berdasarkan index
    bar_image_path = f"assets/power{image_num}.png"
    
    try:
        bar = pygame.image.load(bar_image_path).convert_alpha()
        bar = pygame.transform.scale(bar, (width, height))
        screen.blit(bar, (x, y))
    except pygame.error as e:
        print(f"Error loading image {bar_image_path}: {e}")

# =====================================
# ROUND DISPLAY
# =====================================
def draw_round(screen, round_number, center_x, center_y, alpha=255):

    try:

        # ROUND
        round_img = pygame.image.load(
            "assets/round.png"
        ).convert_alpha()

        round_img.set_alpha(alpha)

        # ANGKA
        digit_surfaces = []

        for digit in str(round_number):

            img = pygame.image.load(
                f"assets/{digit}.png"
            ).convert_alpha()

            img.set_alpha(alpha)

            digit_surfaces.append(img)

        # -----------------------
        # CONFIG
        # -----------------------
        digit_spacing = 8
        vertical_gap = 20

        # -----------------------
        # ROUND (ATAS)
        # -----------------------
        round_x = center_x - round_img.get_width() // 2

        round_y = (
            center_y
            - round_img.get_height()
            - vertical_gap // 2
        )

        screen.blit(
            round_img,
            (
                round_x,
                round_y
            )
        )

        # -----------------------
        # HITUNG TOTAL LEBAR ANGKA
        # -----------------------
        number_width = 0

        for img in digit_surfaces:
            number_width += img.get_width()

        number_width += (
            len(digit_surfaces) - 1
        ) * digit_spacing

        # -----------------------
        # ANGKA (BAWAH)
        # -----------------------
        current_x = center_x - (number_width // 2)

        number_y = (
            center_y
            + vertical_gap // 2
        )

        for img in digit_surfaces:

            screen.blit(
                img,
                (
                    current_x,
                    number_y
                )
            )

            current_x += (
                img.get_width()
                + digit_spacing
            )

    except pygame.error as e:
        print("Round asset error:", e)