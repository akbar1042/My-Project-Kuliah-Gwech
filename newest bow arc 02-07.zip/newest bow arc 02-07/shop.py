import pygame
import save_system

pygame.init()
pygame.mixer.init()

# =====================================
# SOUND EFFECT
# =====================================
swosh_sound = pygame.mixer.Sound("assets/sound/swosh.mp3")
buy_sound = pygame.mixer.Sound("assets/sound/buy.mp3")
equip_sound = pygame.mixer.Sound("assets/sound/equip.mp3")
cancel_sound = pygame.mixer.Sound("assets/sound/cancel.mp3")

# volume (opsional)
swosh_sound.set_volume(0.5)
buy_sound.set_volume(0.6)
equip_sound.set_volume(0.6)
cancel_sound.set_volume(0.5)

WIDTH = 1200
HEIGHT = 700

GOLD_LIGHT = (244, 217, 120)

# =====================================
# LOAD SAVE
# =====================================
data = save_system.load_data()

coin = data["coin"]

# =====================================
# PAGE SYSTEM
# =====================================
current_page = 0
MAX_PAGE = 2

# =====================================
# SLIDE ANIMATION
# =====================================
slide_x = 0
target_x = 0

# =====================================
# BACKGROUND
# =====================================
bg = pygame.image.load("assets/toko.png")
bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))

# =====================================
# BORDER
# =====================================
border = pygame.image.load("assets/border.png")
border_w = 850
border_h = 550
border = pygame.transform.scale(border, (border_w, border_h))
border_x = (WIDTH - border_w) // 2
border_y = ((HEIGHT - border_h) // 2) + 30

# =====================================
# FONT
# =====================================
font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 32)

# =====================================
# BACK BUTTON
# =====================================
back_img = pygame.image.load("assets/back.png")
back_hover = pygame.image.load("assets/back2.png")
back_width = 56
back_height = 56
back_img = pygame.transform.scale(back_img, (back_width, back_height))
back_hover = pygame.transform.scale(back_hover, (back_width, back_height))
back_x = 8
back_y = 8
back_rect = pygame.Rect(back_x, back_y, back_width, back_height)

# =====================================
# NEXT BUTTON
# =====================================
next_img = pygame.image.load("assets/next.png")
next_hover = pygame.image.load("assets/next2.png")
next_width = 110
next_height = 110
next_img = pygame.transform.scale(next_img, (next_width, next_height))
next_hover = pygame.transform.scale(next_hover, (next_width, next_height))
next_x = 1080
next_y = 305
next_rect = pygame.Rect(next_x, next_y, next_width, next_height)

# =====================================
# PREV BUTTON
# =====================================
prev_img = pygame.image.load("assets/prev.png")
prev_hover = pygame.image.load("assets/prev2.png")
prev_width = 110
prev_height = 110
prev_img = pygame.transform.scale(prev_img, (prev_width, prev_height))
prev_hover = pygame.transform.scale(prev_hover, (prev_width, prev_height))
prev_x = 10
prev_y = 305
prev_rect = pygame.Rect(prev_x, prev_y, prev_width, prev_height)

# UPGRADE BUTTON
upgrade_img = pygame.image.load("assets/upgrade.png")
# upgrade_img = pygame.transform.flip(upgrade_img, True, True)

upgrade_img2 = pygame.image.load("assets/upgrade2.png")
# upgrade_img2 = pygame.transform.flip(upgrade_img2, True, True)

upgrade_width = 32
upgrade_height = 32

# BUY BUTTON
buy_img = pygame.image.load("assets/buy.png")
buy_img2 = pygame.image.load("assets/buy2.png")
buy_width = 150
buy_height = 60
buy_img = pygame.transform.scale(buy_img, (buy_width*2, buy_height*1.7))
buy_img2 = pygame.transform.scale(buy_img2, (buy_width*2, buy_height*1.7))

# EQUIP BUTTON
equip_img = pygame.image.load("assets/equip.png")
equip_img2 = pygame.image.load("assets/equip2.png")
equip_width = 150
equip_height = 60
equip_img = pygame.transform.scale(equip_img, (equip_width*2, equip_height*1.7))
equip_img2 = pygame.transform.scale(equip_img2, (equip_width*2, equip_height*1.7))
equipped_img = pygame.image.load("assets/equiped.png") # tambahan
equipped_img = pygame.transform.scale(equipped_img, (equip_width*2, equip_height*1.7))

# =====================================
# COIN IMAGE
# =====================================
coin_img = pygame.image.load("assets/coin.png")
coin_img = pygame.transform.scale(coin_img, (28, 28))

upgrade_x = 0
upgrade_y = 0
buy_x = 0
buy_y = 0
equip_x = 0
equip_y = 0
upgrade_rect1 = pygame.Rect(0, 0, 0, 0)
upgrade_rect2 = pygame.Rect(0, 0, 0, 0)
buy_rect = pygame.Rect(0, 0, 0, 0)
equip_rect = pygame.Rect(0, 0, 0, 0)

clock = pygame.time.Clock()
# =====================================
# NOTIFICATION
# =====================================
notification_text = ""
notification_timer = 0

NOTIF_FADE_IN = 20
NOTIF_HOLD = 60
NOTIF_FADE_OUT = 20
NOTIF_TOTAL = NOTIF_FADE_IN + NOTIF_HOLD + NOTIF_FADE_OUT

# =====================================
# ⬇️ TAMBAH DI SINI — CHARACTER DATA
# =====================================
characters = [
    {
        "name": "Ciro",
        "img": "assets/Characters/ciro11.png",
        "hp": data["Ciro"]["hp"],
        "atk": data["Ciro"]["atk"],
        "hp_price": data["Ciro"]["hp_price"],
        "atk_price": data["Ciro"]["atk_price"],
        "hp_up": data["Ciro"]["hp_up"],
        "atk_up": data["Ciro"]["atk_up"],
        "skill": data["Ciro"]["skill"],
        "price": 0,
        "owned": data["Ciro"]["owned"],
        "buy_rect": None,
        "equip_rect": None,
        "upgrade_rects": [],
    },
    
    {
        "name": "Lulia",
        "img": "assets/Characters/lulia11.png",
        "hp": data["Lulia"]["hp"],
        "atk": data["Lulia"]["atk"],
        "hp_up": data["Lulia"]["hp_up"],
        "atk_up": data["Lulia"]["atk_up"],
        "hp_price": data["Lulia"]["hp_price"],
        "atk_price": data["Lulia"]["atk_price"],
        "skill": data["Lulia"]["skill"],
        "price": 10000,
        "owned": data["Lulia"]["owned"],
        "buy_rect": None,
        "equip_rect": None,
        "upgrade_rects": [],
    },
    
    {
        "name": "John",
        "img": "assets/Characters/jon11.png",
        "hp": data["John"]["hp"],
        "atk": data["John"]["atk"],
        "hp_up": data["John"]["hp_up"],
        "atk_up": data["John"]["atk_up"],
        "hp_price": data["John"]["hp_price"],
        "atk_price": data["John"]["atk_price"],
        "skill": data["John"]["skill"],
        "price": 100000,
        "owned": data["John"]["owned"],
        "buy_rect": None,
        "equip_rect": None,
        "upgrade_rects": [],
    }
]

def draw_character_card(screen, char, card_x, card_y):
    global upgrade_x, upgrade_y, upgrade_rects, buy_x, buy_y, buy_rect, equip_x, equip_y, equip_rect
    card_width  = 700
    card_height = 360
    mouse_pos = pygame.mouse.get_pos()

    char_img = pygame.image.load(char["img"])
    char_img = pygame.transform.scale(
        char_img,
        (220, 320)
        )
    screen.blit(char_img, (card_x + 30, card_y))

    name_font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 50)
    name_surf = name_font.render(char["name"], True, GOLD_LIGHT)
    name_rect = name_surf.get_rect(center=(card_x+130, card_y))

    price_font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 30)
    price_surf = price_font.render(f"{char['price']}", True, GOLD_LIGHT)
    price_rect = price_surf.get_rect(center=(card_x + 455, card_y - 35))
    
    coin_rect = coin_img.get_rect(midleft=(price_rect.right + 10, price_rect.centery - 2))
    
    screen.blit(name_surf, name_rect)
    screen.blit(price_surf, price_rect)
    screen.blit(coin_img, coin_rect)

    stat_font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 30)
    stats_x = card_x + 280
    stats_y = card_y + 14
    line_h   = 55
    
    stats = [
        ("HP",  char["hp"],  char["hp_price"],  (244, 217, 120)),
        ("ATK", char["atk"], char["atk_price"], (244, 217, 120)),
    ]

    char["upgrade_rects"] = []
    
    for label, val, up, color in stats:
        label_surf = stat_font.render(
            f"{label} : {val}",
            True,
            GOLD_LIGHT
            )
        
        screen.blit(label_surf, (stats_x, stats_y))
        badge_surf = stat_font.render(
            f"{up}",
            True,
            color
            )
        
        upgrade_x = stats_x + 260
        upgrade_y = stats_y - 2
        upgrade_rect = pygame.Rect(upgrade_x, upgrade_y, upgrade_width, upgrade_height)
        char["upgrade_rects"].append(upgrade_rect)

        
        badge_rect = badge_surf.get_rect(center=(stats_x + 320, stats_y + 15))
        coin_rect = coin_img.get_rect(midleft=(badge_rect.right + 10, badge_rect.centery - 2))
        
        screen.blit(badge_surf, badge_rect)
        screen.blit(coin_img, coin_rect)
        
        stats_y += line_h
        
    skill_surf = stat_font.render(f"Skill : {char['skill']}", True, (255, 200, 50))
    screen.blit(skill_surf, (stats_x, stats_y))

    #posisi btn
    # setelah: screen.blit(skill_surf, (stats_x, stats_y))

    global buy_x, buy_y, equip_x, equip_y, buy_rect, equip_rect

    btn_x = stats_x + 50
    btn_y = stats_y + 130

    buy_x = btn_x 
    buy_y = btn_y + 10
    char["buy_rect"] = pygame.Rect(buy_x, buy_y, buy_width * 2, buy_height * 1.7)

    equip_x = btn_x
    equip_y = btn_y
    char["equip_rect"] = pygame.Rect(equip_x, equip_y, equip_width * 2, equip_height * 1.7)
    
    #berubah
    if char["owned"]:

        is_equipped = data.get(char["name"], {}).get("equipped", False)

        if is_equipped:
            screen.blit(equipped_img, (equip_x, equip_y))

        elif char["equip_rect"].collidepoint(mouse_pos):
            screen.blit(equip_img2, (equip_x, equip_y))

        else:
            screen.blit(equip_img, (equip_x, equip_y))

    else:

        if char["buy_rect"].collidepoint(mouse_pos):
            screen.blit(buy_img2, (buy_x, buy_y))

        else:
            screen.blit(buy_img, (buy_x, buy_y))
            
     #2       
            
    for i, rect in enumerate(char["upgrade_rects"]):

        if rect.collidepoint(mouse_pos):
            screen.blit(upgrade_img2, (rect.x, rect.y))
        else:
            screen.blit(upgrade_img, (rect.x, rect.y))

# =====================================
# GANTI fungsi draw_page yang lama
# =====================================
def draw_page(screen, page_x, page_index):

    screen.blit(border, (page_x + border_x, border_y))

    if page_index < len(characters):
        char = characters[page_index]
        card_x = page_x + (WIDTH - 700) // 2
        card_y = border_y + 120
        draw_character_card(screen, char, card_x, card_y)


def show_notification(text):
    global notification_text, notification_timer

    notification_text = text
    notification_timer = NOTIF_TOTAL
    

# =====================================
# SHOP
# =====================================
def run(screen):

    global current_page, slide_x, target_x, coin, data
    global current_page
    global slide_x
    global target_x
    global coin
    global data
    global notification_timer
    global notification_text

    running = True

    while running:

        clock.tick(60)

        data = save_system.load_data()
        coin = data["coin"]

        for c in characters:
            c["owned"] = data[c["name"]]["owned"]
            c["hp"] = data[c["name"]]["hp"]
            c["atk"] = data[c["name"]]["atk"]

        mouse_pos = pygame.mouse.get_pos()

        slide_x += (target_x - slide_x) * 0.1

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                return None

            if event.type == pygame.MOUSEBUTTONDOWN:

                # =========================
                # BACK BUTTON
                # =========================
                if back_rect.collidepoint(mouse_pos):
                    cancel_sound.play()
                    pygame.time.delay(150)
                    running = False

                # =========================
                # NEXT BUTTON
                # =========================
                if next_rect.collidepoint(mouse_pos):
                    if current_page < MAX_PAGE:
                        swosh_sound.play()
                        current_page += 1
                        target_x -= WIDTH

                # =========================
                # PREV BUTTON
                # =========================
                if prev_rect.collidepoint(mouse_pos):
                    if current_page > 0:
                        swosh_sound.play()
                        current_page -= 1
                        target_x += WIDTH

                # =========================
                # CHARACTER ACTIVE
                # =========================
                char = characters[current_page]

                # =========================
                # UPGRADE BUTTON
                # =========================
                if len(char["upgrade_rects"]) >= 2:

                    # HP
                    if char["upgrade_rects"][0].collidepoint(mouse_pos):
                        if coin >= char["hp_price"] and char["owned"]:
                            coin -= char["hp_price"]
                            char["hp"] += char["hp_up"]
                            char["hp_price"] = round(int(char["hp_price"]) * 1.1)
                            
                            data[char["name"]]["hp_price"] = char["hp_price"]
                            data[char["name"]]["hp"] = char["hp"]
                            data["coin"] = coin

                            save_system.save_data(data)
                            buy_sound.play()
                            
                        elif coin >= char["hp_price"] and not char["owned"]:
                            show_notification("Beli Hero dulu Bang!")
                        else:
                            show_notification("Farming Lagi Bang!")

                    # ATK
                    if char["upgrade_rects"][1].collidepoint(mouse_pos):

                        if coin >= char["atk_price"] and char["owned"]:
                            coin -= char["atk_price"]
                            char["atk"] += char["atk_up"]
                            char["atk_price"] = round(int(char["atk_price"]) * 1.1)
                            
                            data[char["name"]]["atk_price"] = char["atk_price"]
                            data[char["name"]]["atk"] = char["atk"]
                            data["coin"] = coin

                            save_system.save_data(data)
                            buy_sound.play()
                        
                        elif coin >= char["atk_price"] and not char["owned"]:
                            show_notification("Beli Hero dulu Bang!")
                        else:
                            show_notification("Farming Lagi Bang!")

                # =========================
                # BUY BUTTON
                # =========================
                if (
                    char["buy_rect"] and
                    char["buy_rect"].collidepoint(mouse_pos) and
                    not char["owned"]
                ):

                    if coin >= char["price"]:

                        coin -= char["price"]

                        char["owned"] = True

                        data[char["name"]]["owned"] = True
                        data["coin"] = coin

                        save_system.save_data(data)
                        buy_sound.play()

                    else:
                            show_notification("Farming Lagi Bang!")
                    

                # =========================
                # EQUIP BUTTON
                # =========================
                if (
                    char["equip_rect"] and
                    char["equip_rect"].collidepoint(mouse_pos) and
                    char["owned"]
                ):

                    for c in characters:
                        data[c["name"]]["equipped"] = False

                    data[char["name"]]["equipped"] = True

                    save_system.save_data(data)
                    equip_sound.play()

        # =========================
        # DRAW
        # =========================
        screen.blit(bg, (0, 0))

        pages = [
            0 + slide_x,
            WIDTH + slide_x,
            WIDTH * 2 + slide_x
        ]

        for i, page_x in enumerate(pages):

            if -WIDTH < page_x < WIDTH:
                draw_page(screen, page_x, i)

        # =========================
        # COIN
        # =========================
        font.set_bold(True)

        coin_text = font.render(str(coin), True, GOLD_LIGHT)

        screen.blit(coin_text, (840, 21))

        # =========================
        # BACK BUTTON DRAW
        # =========================
        if back_rect.collidepoint(mouse_pos):
            screen.blit(back_hover, (back_x, back_y))
        else:
            screen.blit(back_img, (back_x, back_y))

        # =========================
        # NEXT BUTTON DRAW
        # =========================
        if current_page < MAX_PAGE:

            if next_rect.collidepoint(mouse_pos):
                screen.blit(next_hover, (next_x, next_y))
            else:
                screen.blit(next_img, (next_x, next_y))

        # =========================
        # PREV BUTTON DRAW
        # =========================
        if current_page > 0:

            if prev_rect.collidepoint(mouse_pos):
                screen.blit(prev_hover, (prev_x, prev_y))
            else:
                screen.blit(prev_img, (prev_x, prev_y))

        # =====================================
# NOTIFICATION DRAW
# =====================================
        if notification_timer > 0:

            elapsed = NOTIF_TOTAL - notification_timer

            if elapsed < NOTIF_FADE_IN:
                alpha = int(255 * (elapsed / NOTIF_FADE_IN))

            elif elapsed < NOTIF_FADE_IN + NOTIF_HOLD:
                alpha = 255

            else:
                fade_elapsed = elapsed - (NOTIF_FADE_IN + NOTIF_HOLD)
                alpha = int(255 * (1 - fade_elapsed / NOTIF_FADE_OUT))

            notif_font = pygame.font.Font(
                "assets/font/MinecraftRegular-Bmg3.ttf",
                40
            )

            text_surf = notif_font.render(
                notification_text,
                True,
                (0, 0, 0)
            )

            text_surf.set_alpha(alpha)

            text_rect = text_surf.get_rect(
                center=(WIDTH // 2, HEIGHT - 100)
            )

            screen.blit(text_surf, text_rect)

            notification_timer -= 1
                
        pygame.display.update()