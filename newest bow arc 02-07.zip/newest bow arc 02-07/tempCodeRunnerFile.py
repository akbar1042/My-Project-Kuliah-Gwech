def load_gif(path, w, h):
    frames = []
    try:
        from PIL import Image
        gif = Image.open(path)

        try:
            while True:
                frame = gif.copy().convert("RGBA")
                surf = pygame.image.fromstring(
                    frame.tobytes(), frame.size, "RGBA"
                ).convert_alpha()
                frames.append(pygame.transform.scale(surf, (w, h)))
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass
