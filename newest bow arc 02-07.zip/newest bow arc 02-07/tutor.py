import pygame

pygame.init()
pygame.mixer.init()

WIDTH = 1200
HEIGHT = 700

# =========================
# SOUND (BACK BUTTON)
# =========================
back_sfx = pygame.mixer.Sound("assets/sound/hah.mp3")
back_sfx.set_volume(0.6)


# =========================
# BACKGROUND TUTOR
# =========================
tutor_bg = pygame.image.load("assets/tutor.png")

bg_width = 960
bg_height = 650

tutor_bg = pygame.transform.scale(tutor_bg, (bg_width, bg_height))

bg_x = (WIDTH - bg_width) // 2
bg_y = (HEIGHT - bg_height) // 2


# =========================
# TOMBOL KEMBALI
# =========================
back1 = pygame.image.load("assets/kembali.png")
back2 = pygame.image.load("assets/kembali2.png")

back_width = 240
back_height = 80

back1 = pygame.transform.scale(back1, (back_width, back_height))
back2 = pygame.transform.scale(back2, (back_width, back_height))

back_x = bg_x + (bg_width - back_width) // 2
back_y = bg_y + bg_height - back_height - 25

back_rect = pygame.Rect(back_x, back_y, back_width, back_height)


# =========================
# FONT
# =========================
font = pygame.font.Font("assets/font/MinecraftRegular-Bmg3.ttf", 28)
text_color = (60, 30, 10)

tutorial_text = [
    "TUTORIAL!",
    "1. Tarik mouse untuk menembak",
    "2. Arah panah mengikuti mouse",
    "3. Kalahkan semua musuh",
    "4. Hindari terkena serangan",
    "5. Tekan Spasi untuk pause"
]

clock = pygame.time.Clock()


# =========================
# RUN
# =========================
def run(screen):

    running = True

    while running:

        clock.tick(60)
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                return

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            if event.type == pygame.MOUSEBUTTONDOWN:

                if back_rect.collidepoint(mouse_pos):
                    back_sfx.play()
                    running = False


        # =========================
        # DRAW BACKGROUND
        # =========================
        screen.blit(tutor_bg, (bg_x, bg_y))


        # =========================
        # DRAW TEXT
        # =========================
        start_y = bg_y + 150

        for i, text in enumerate(tutorial_text):

            render_text = font.render(text, True, text_color)

            text_x = bg_x + (bg_width - render_text.get_width()) // 2
            text_y = start_y + (i * 45)

            screen.blit(render_text, (text_x, text_y))


        # =========================
        # BACK BUTTON
        # =========================
        if back_rect.collidepoint(mouse_pos):
            screen.blit(back2, (back_x, back_y))
        else:
            screen.blit(back1, (back_x, back_y))

        pygame.display.update()